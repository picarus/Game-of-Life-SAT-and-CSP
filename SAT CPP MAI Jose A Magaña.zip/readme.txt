To execute the whole process, run:

bash sat.sh <file_no_ext>

where <file> is the name of the file without its extension.

The script will look for <file>.txt as input.

The script generates:

<file>cnf.txt with the DIMACS file
<file>cnfout.txt with the MINISAT output
<file>out.txt with the board output